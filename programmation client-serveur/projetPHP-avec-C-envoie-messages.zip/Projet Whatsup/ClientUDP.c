//Client en mode non connecté
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netdb.h>
#include<unistd.h>
#include<arpa/inet.h>
#include <signal.h>
int main(int argc, char** argv)
{
	int sd,nb,ns,read;
	struct sockaddr_in cltaddr, servaddr;
	socklen_t svrAdrSize = sizeof(servaddr); //Pour la taille de l'adresse du serveur

	//création du socket en mode non connecté
	sd=socket(AF_INET, SOCK_DGRAM, 0);

	//Préparation de l'adresse du Client
	cltaddr.sin_family= AF_INET;
	cltaddr.sin_port=1601;
	cltaddr.sin_addr.s_addr=INADDR_ANY;
	if((nb = bind(sd, (struct sockaddr *)&cltaddr, sizeof(cltaddr))) < 0 )
		printf("Problème d'attachement du socket");

	//Préparation de l'adresse du serveur
	servaddr.sin_family= AF_INET;
	servaddr.sin_port=1600;
	servaddr.sin_addr.s_addr=INADDR_ANY;

	//Envoie du message au serveur
	if (sendto(sd, argv[1], sizeof(argv[1]) , 0, (struct sockaddr *) &servaddr, sizeof(servaddr) )<0)
		printf("Problème d'envoie");

	close(sd);
	exit(0);
}