<?php
define('HOST',"127.0.0.1");
define('USER',"root");
define('PASS',"root");
define('DBNAME',"whatsup");
$connection = mysqli_connect(HOST, USER, PASS, DBNAME);
	if($connection==false) echo "Connection Problem";
?>