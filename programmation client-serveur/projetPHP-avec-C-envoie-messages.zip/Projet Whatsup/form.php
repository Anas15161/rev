<?php
		require_once 'connection.php';
		$query = "select * from messages";
		$result = mysqli_query($connection, $query);
		while($message = mysqli_fetch_array($result))
			echo $message['message'].' <i>'.$message['datemsg'].'</i><hr>';
?>
<form>
<textarea name="msg"></textarea>
<input type="submit">
</form>
<form>
<input type="submit" name="exit" value="Exit">
</form>
<?php
if(isset($_GET['msg'])) 
	{
		require_once 'connection.php';
		shell_exec('./ClientUDP'.' '.$_GET['msg']);
		$msg = $_GET['msg'];
		$query = "insert into messages values (null, '$msg', null)";
		mysqli_query($connection, $query);
		mysqli_close($connection);
		header('location:form.php');
	}

if(isset($_GET['exit'])) 
	{
		shell_exec('./ClientUDP'.' exit');
		header('location:form.php');
	}
	
?>