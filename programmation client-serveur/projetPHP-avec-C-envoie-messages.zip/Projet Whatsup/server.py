#server.py
import os
os.system('./ServerUDP')